import pandas as pd
data1=pd.read_csv("banknotes.csv")
data1.shape
X=data1[['Variance','Skewness','Curtosis','Entropy']]
print(X)
#or data.drop('Class',axis=1)Here Axis 1 is column wise
y=data1['Class']
print(y)
#to check any null values
print(X.isnull().sum())
#to check value y is there any other than 0 and 1
print(set(y))#return type is set not iterable

#another to find is that y is unique\
import numpy as np
print('unique Values:',np.unique(y))#it can be iterable

#to check the accuracy for this purpose we are going to train test and split .
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,random_state= 0)#random state because it is sorted so our  model dwill no know if we not give random

print('Length of Train Data',len(X_train))
len(X_test)#check wheter the entry are corerct

print('First five of train_data','First Five of y_train data',X_train.head(),y_train.head())
#lets build classifier.Output is continuos then regression.
#tree having the Dicison tree classifier
#gini is for impurity
#check website for sklearn dicisionTree for More.

from sklearn.tree import DecisionTreeClassifier
classifier=DecisionTreeClassifier()#same as regression technique
classifier.fit(X_train,y_train)

#three diff characterization.wheteher clasifier is true or not.
y_pred=classifier.predict(X_test)#all 343 values given to test
len(y_pred)

y_pred#prdicting with the sample
y_test#this is original data

y_test.head(10)

print(y_pred)#first ten are applying accurate.
#Confusion MAtrix how many entries are macthing and not matching
from sklearn.metrics import confusion_matrix
confusion_matrix(y_test,y_pred)#y_test rows #y_pred column wise

#0 predicted as 0 at 194 and predict as 1 for 1 time
#1 predicted as 0 at 3 and predict 1 as 145
339/343*100#that number of entries are matching #adv for this dicision tree is fastest

#we can find the accuracy score
from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_pred)*100#first paramenter as testing data and second as predicting data

from sklearn.metrics import classification_report
print(classification_report(y_test,y_pred))
#Classification report genrates this kinf of output 
#output
#array([[194,   1],
 #      [  3, 145]])
#194,   1
#3, 145
#support is the count for the test_data
#recall is indivisual class accuracy
#precison true positive rate -how many entries are true postive in predictive data
#outof 197 194 are entries are match that is why 98 percent accuracy are there
#f1 score add the precison + recall divided by 2



#d=[ 	Variance 	Skewness 	Curtosis 	Entropy]
#to input use numpy and all input of the values
d= [[2.9736 ,8.7944 ,-3.6359 ,-1.375400]]
pred=classifier.predict(d)
if pred[0]==0:
        print('Fake Note')
else :
    print('Not Fake')


#visualize the tree
from sklearn.externals.six import StringIO
from IPython.display import Image
from sklearn.tree import export_graphviz
import pydotplus
dot_data=StringIO()
export_graphviz(classifier,out_file=dot_data,filled=True,rounded=True,special_characters=True)
graph=pydotplus.graph_from_dot_data(dot_data.getvalue())
graph.write_png('tree.png')










